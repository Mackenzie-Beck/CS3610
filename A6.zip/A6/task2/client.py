from ComputerManager import ComputerManager

controller = ComputerManager()

print("\n")

controller.beginWork()

print("\n")

controller.turnOff()