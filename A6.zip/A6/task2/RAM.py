from Hardware import Hardware

class RAM(Hardware):
    
    def launchDevices(self):
        print("RAM devices launched")

    def analyzeMem(self):
        print("Memory has been analyzed")
    
    def clearMem(self):
        print("Memory has been cleared")
        