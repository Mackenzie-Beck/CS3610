

class WeatherForecastSystem():
    def __init__(self):
        pass    

    def makeForecast(self, xml_data):
        print('\n')
        print(f"WeatherForecastSystem received XML data: {xml_data}")
        print("Performing weather forecast...")
        print("WeatherForecastSystem returning XML data: Forecast data")
        return "Forecast data"