




class Sensor():
    def __init__(self):
        pass

    def getSensorData(self):
        return "Sensor data"